﻿using DisasterAlleviationFoundation.Models.ViewModels;
using DisasterAlleviationFoundation.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace DisasterAlleviationFoundation.Controllers
{
    [Authorize]
    public class VolunteerController : Controller
    {
        private readonly IVolunteerService _volunteerService;
        private readonly IDisasterService _disasterService;

        public VolunteerController(IVolunteerService volunteerService, IDisasterService disasterService)
        {
            _volunteerService = volunteerService;
            _disasterService = disasterService;
        }

        // GET: Volunteer/Register
        public IActionResult Register()
        {
            ViewBag.AvailabilityOptions = new SelectList(new[] { "Full-time", "Part-time", "Weekends", "Emergency Only" });
            return View();
        }

        // POST: Volunteer/Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(VolunteerRegisterModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await _volunteerService.RegisterAsVolunteerAsync(model, User.Identity.Name);
                if (result)
                {
                    return RedirectToAction(nameof(Profile));
                }
                ModelState.AddModelError("", "You are already registered as a volunteer.");
            }

            ViewBag.AvailabilityOptions = new SelectList(new[] { "Full-time", "Part-time", "Weekends", "Emergency Only" });
            return View(model);
        }

        // GET: Volunteer/Profile
        public async Task<IActionResult> Profile()
        {
            var volunteer = await _volunteerService.GetVolunteerByUserIdAsync(User.Identity.Name);
            if (volunteer == null)
            {
                return RedirectToAction(nameof(Register));
            }

            var tasks = await _volunteerService.GetTasksByVolunteerAsync(volunteer.Id);

            var viewModel = new VolunteerViewModel
            {
                Id = volunteer.Id,
                Skills = volunteer.Skills,
                Availability = volunteer.Availability,
                Location = volunteer.Location,
                UserName = volunteer.User.UserName,
                Email = volunteer.User.Email,
                FullName = $"{volunteer.User.FirstName} {volunteer.User.LastName}",
                IsActive = volunteer.IsActive,
                RegistrationDate = volunteer.RegistrationDate
            };

            ViewBag.Tasks = tasks;
            return View(viewModel);
        }

        // GET: Volunteer/Tasks
        public async Task<IActionResult> Tasks()
        {
            var volunteer = await _volunteerService.GetVolunteerByUserIdAsync(User.Identity.Name);
            if (volunteer == null)
            {
                return RedirectToAction(nameof(Register));
            }

            var availableTasks = await _volunteerService.GetAvailableTasksAsync();
            var myTasks = await _volunteerService.GetTasksByVolunteerAsync(volunteer.Id);

            ViewBag.AvailableTasks = availableTasks;
            ViewBag.MyTasks = myTasks;
            ViewBag.VolunteerId = volunteer.Id;

            return View();
        }

        // POST: Volunteer/AssignTask
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AssignTask(int taskId, int volunteerId)
        {
            await _volunteerService.AssignVolunteerToTaskAsync(taskId, volunteerId);
            return RedirectToAction(nameof(Tasks));
        }

        // POST: Volunteer/CompleteTask
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CompleteTask(int taskId)
        {
            await _volunteerService.CompleteTaskAsync(taskId);
            return RedirectToAction(nameof(Tasks));
        }

        // GET: Volunteer/Manage (Admin only)
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Manage()
        {
            var volunteers = await _volunteerService.GetAllVolunteersAsync();
            var tasks = await _volunteerService.GetAvailableTasksAsync();

            ViewBag.Volunteers = new SelectList(volunteers, "Id", "User.FullName");
            ViewBag.DisasterIncidents = new SelectList(await _disasterService.GetActiveIncidentsAsync(), "Id", "Title");

            return View((volunteers, tasks));
        }

        // POST: Volunteer/CreateTask (Admin only)
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> CreateTask(VolunteerTaskViewModel model)
        {
            if (ModelState.IsValid)
            {
                await _volunteerService.CreateVolunteerTaskAsync(model);
                return RedirectToAction(nameof(Manage));
            }

            var volunteers = await _volunteerService.GetAllVolunteersAsync();
            var tasks = await _volunteerService.GetAvailableTasksAsync();

            ViewBag.Volunteers = new SelectList(volunteers, "Id", "User.FullName");
            ViewBag.DisasterIncidents = new SelectList(await _disasterService.GetActiveIncidentsAsync(), "Id", "Title");

            return View("Manage", (volunteers, tasks));
        }
    }
}