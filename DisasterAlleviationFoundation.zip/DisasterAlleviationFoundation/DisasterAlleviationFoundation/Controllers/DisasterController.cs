﻿using DisasterAlleviationFoundation.Models.ViewModels;
using DisasterAlleviationFoundation.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DisasterAlleviationFoundation.Controllers
{
    [Authorize]
    public class DisasterController : Controller
    {
        private readonly IDisasterService _disasterService;

        public DisasterController(IDisasterService disasterService)
        {
            _disasterService = disasterService;
        }

        // GET: Disaster
        public async Task<IActionResult> Index()
        {
            var incidents = await _disasterService.GetAllIncidentsAsync();
            return View(incidents);
        }

        // GET: Disaster/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var incident = await _disasterService.GetIncidentByIdAsync(id);
            if (incident == null)
            {
                return NotFound();
            }

            var viewModel = new DisasterIncidentViewModel
            {
                Id = incident.Id,
                Title = incident.Title,
                Description = incident.Description,
                Location = incident.Location,
                DisasterType = incident.DisasterType,
                Severity = incident.Severity,
                IsActive = incident.IsActive
            };

            return View(viewModel);
        }

        // GET: Disaster/Create
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Disaster/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create(DisasterIncidentCreateModel model)
        {
            if (ModelState.IsValid)
            {
                await _disasterService.CreateIncidentAsync(model, User.Identity.Name);
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        // GET: Disaster/Edit/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id)
        {
            var incident = await _disasterService.GetIncidentByIdAsync(id);
            if (incident == null)
            {
                return NotFound();
            }

            var viewModel = new DisasterIncidentViewModel
            {
                Id = incident.Id,
                Title = incident.Title,
                Description = incident.Description,
                Location = incident.Location,
                DisasterType = incident.DisasterType,
                Severity = incident.Severity,
                IsActive = incident.IsActive
            };

            return View(viewModel);
        }

        // POST: Disaster/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id, DisasterIncidentViewModel model)
        {
            if (id != model.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                await _disasterService.UpdateIncidentAsync(model);
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        // POST: Disaster/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            await _disasterService.DeleteIncidentAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}