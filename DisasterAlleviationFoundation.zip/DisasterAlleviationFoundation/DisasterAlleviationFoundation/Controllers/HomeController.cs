using DisasterAlleviationFoundation.Models;
using DisasterAlleviationFoundation.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DisasterAlleviationFoundation.Controllers
{
    public class HomeController : Controller
    {
        private readonly IDisasterService _disasterService;
        private readonly ILogger<HomeController> _logger;

        public HomeController(IDisasterService disasterService, ILogger<HomeController> logger)
        {
            _disasterService = disasterService;
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            var incidents = await _disasterService.GetActiveIncidentsAsync();
            return View(incidents);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}