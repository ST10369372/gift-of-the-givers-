﻿using DisasterAlleviationFoundation.Data;
using DisasterAlleviationFoundation.Models.ViewModels;
using DisasterAlleviationFoundation.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace DisasterAlleviationFoundation.Controllers
{
    [Authorize]
    public class DonationController : Controller
    {
        private readonly IDonationService _donationService;
        private readonly IDisasterService _disasterService;
        private readonly AppDbContext _context;

        public DonationController(IDonationService donationService, IDisasterService disasterService, AppDbContext context)
        {
            _donationService = donationService;
            _disasterService = disasterService;
            _context = context;
        }

        // GET: Donation
        public async Task<IActionResult> Index()
        {
            var donations = await _donationService.GetDonationsByUserAsync(User.Identity.Name);
            return View(donations);
        }

        // GET: Donation/All (Admin only)
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> All()
        {
            var donations = await _donationService.GetAllDonationsAsync();
            return View(donations);
        }

        // GET: Donation/Create
        public async Task<IActionResult> Create()
        {
            var activeDisasters = await _disasterService.GetActiveIncidentsAsync();
            ViewBag.DisasterIncidentId = new SelectList(activeDisasters, "Id", "Title");
            ViewBag.ResourceTypes = new SelectList(new[] { "Food", "Clothing", "Medical Supplies", "Shelter Materials", "Money", "Other" });
            return View();
        }

        // POST: Donation/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(DonationCreateModel model)
        {
            if (ModelState.IsValid)
            {
                await _donationService.CreateDonationAsync(model, User.Identity.Name);
                return RedirectToAction(nameof(Index));
            }

            var activeDisasters = await _disasterService.GetActiveIncidentsAsync();
            ViewBag.DisasterIncidentId = new SelectList(activeDisasters, "Id", "Title");
            ViewBag.ResourceTypes = new SelectList(new[] { "Food", "Clothing", "Medical Supplies", "Shelter Materials", "Money", "Other" });
            return View(model);
        }

        // GET: Donation/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var donation = await _donationService.GetDonationByIdAsync(id);
            if (donation == null)
            {
                return NotFound();
            }

            // Check if user owns the donation or is admin
            if (donation.DonorId != User.Identity.Name && !User.IsInRole("Admin"))
            {
                return Forbid();
            }

            var viewModel = new DonationViewModel
            {
                Id = donation.Id,
                ResourceType = donation.ResourceType,
                ItemName = donation.ItemName,
                Quantity = donation.Quantity,
                Description = donation.Description,
                Status = donation.Status,
                DonatedDate = donation.DonatedDate,
                DonorName = $"{donation.Donor.FirstName} {donation.Donor.LastName}",
                DisasterIncidentId = donation.DisasterIncidentId
            };

            return View(viewModel);
        }

        // POST: Donation/UpdateStatus/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateStatus(int id, string status)
        {
            await _donationService.UpdateDonationStatusAsync(id, status);
            return RedirectToAction(nameof(All));
        }
    }
}