﻿using DisasterAlleviationFoundation.Data;
using DisasterAlleviationFoundation.Models;
using DisasterAlleviationFoundation.Models.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace DisasterAlleviationFoundation.Services
{
    public interface IVolunteerService
    {
        Task<bool> RegisterAsVolunteerAsync(VolunteerRegisterModel model, string userId);
        Task<Volunteer> GetVolunteerByUserIdAsync(string userId);
        Task<IEnumerable<Volunteer>> GetAllVolunteersAsync();
        Task CreateVolunteerTaskAsync(VolunteerTaskViewModel model);
        Task<IEnumerable<VolunteerTask>> GetAvailableTasksAsync();
        Task<IEnumerable<VolunteerTask>> GetTasksByVolunteerAsync(int volunteerId);
        Task AssignVolunteerToTaskAsync(int taskId, int volunteerId);
        Task CompleteTaskAsync(int taskId);
    }

    public class VolunteerService : IVolunteerService
    {
        private readonly AppDbContext _context;

        public VolunteerService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<bool> RegisterAsVolunteerAsync(VolunteerRegisterModel model, string userId)
        {
            var existingVolunteer = await _context.Volunteers
                .FirstOrDefaultAsync(v => v.UserId == userId);

            if (existingVolunteer != null)
                return false; // Already registered

            var volunteer = new Volunteer
            {
                UserId = userId,
                Skills = model.Skills,
                Availability = model.Availability,
                Location = model.Location,
                RegistrationDate = DateTime.UtcNow,
                IsActive = true
            };

            _context.Volunteers.Add(volunteer);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<Volunteer> GetVolunteerByUserIdAsync(string userId)
        {
            return await _context.Volunteers
                .Include(v => v.User)
                .Include(v => v.Tasks)
                .FirstOrDefaultAsync(v => v.UserId == userId);
        }

        public async Task<IEnumerable<Volunteer>> GetAllVolunteersAsync()
        {
            return await _context.Volunteers
                .Where(v => v.IsActive)
                .Include(v => v.User)
                .Include(v => v.Tasks)
                .ToListAsync();
        }

        public async Task CreateVolunteerTaskAsync(VolunteerTaskViewModel model)
        {
            var task = new VolunteerTask
            {
                TaskName = model.TaskName,
                Description = model.Description,
                ScheduledDate = model.ScheduledDate,
                Location = model.Location,
                Status = "Pending",
                DisasterIncidentId = model.DisasterIncidentId,
                CreatedDate = DateTime.UtcNow
            };

            _context.VolunteerTasks.Add(task);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<VolunteerTask>> GetAvailableTasksAsync()
        {
            return await _context.VolunteerTasks
                .Where(t => t.Status == "Pending")
                .Include(t => t.DisasterIncident)
                .OrderBy(t => t.ScheduledDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<VolunteerTask>> GetTasksByVolunteerAsync(int volunteerId)
        {
            return await _context.VolunteerTasks
                .Where(t => t.VolunteerId == volunteerId)
                .Include(t => t.DisasterIncident)
                .OrderByDescending(t => t.ScheduledDate)
                .ToListAsync();
        }

        public async Task AssignVolunteerToTaskAsync(int taskId, int volunteerId)
        {
            var task = await _context.VolunteerTasks.FindAsync(taskId);
            if (task != null)
            {
                task.VolunteerId = volunteerId;
                task.Status = "Assigned";
                await _context.SaveChangesAsync();
            }
        }

        public async Task CompleteTaskAsync(int taskId)
        {
            var task = await _context.VolunteerTasks.FindAsync(taskId);
            if (task != null)
            {
                task.Status = "Completed";
                await _context.SaveChangesAsync();
            }
        }
    }
}