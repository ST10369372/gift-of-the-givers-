﻿using DisasterAlleviationFoundation.Data;
using DisasterAlleviationFoundation.Models;
using DisasterAlleviationFoundation.Models.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace DisasterAlleviationFoundation.Services
{
    public interface IDisasterService
    {
        Task<IEnumerable<DisasterIncident>> GetActiveIncidentsAsync();
        Task<DisasterIncident> GetIncidentByIdAsync(int id);
        Task CreateIncidentAsync(DisasterIncidentCreateModel model, string userId);
        Task UpdateIncidentAsync(DisasterIncidentViewModel model);
        Task DeleteIncidentAsync(int id);
        Task<IEnumerable<DisasterIncident>> GetAllIncidentsAsync();
    }

    public class DisasterService : IDisasterService
    {
        private readonly AppDbContext _context;

        public DisasterService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<DisasterIncident>> GetActiveIncidentsAsync()
        {
            return await _context.DisasterIncidents
                .Where(d => d.IsActive)
                .OrderByDescending(d => d.ReportedDate)
                .Include(d => d.ReportedBy)
                .ToListAsync();
        }

        public async Task<DisasterIncident> GetIncidentByIdAsync(int id)
        {
            return await _context.DisasterIncidents
                .Include(d => d.ReportedBy)
                .FirstOrDefaultAsync(d => d.Id == id);
        }

        public async Task CreateIncidentAsync(DisasterIncidentCreateModel model, string userId)
        {
            var incident = new DisasterIncident
            {
                Title = model.Title,
                Description = model.Description,
                Location = model.Location,
                DisasterType = model.DisasterType,
                Severity = model.Severity,
                ReportedByUserId = userId,
                ReportedDate = DateTime.UtcNow,
                IsActive = true
            };

            _context.DisasterIncidents.Add(incident);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateIncidentAsync(DisasterIncidentViewModel model)
        {
            var incident = await _context.DisasterIncidents.FindAsync(model.Id);
            if (incident != null)
            {
                incident.Title = model.Title;
                incident.Description = model.Description;
                incident.Location = model.Location;
                incident.DisasterType = model.DisasterType;
                incident.Severity = model.Severity;
                incident.IsActive = model.IsActive;

                await _context.SaveChangesAsync();
            }
        }

        public async Task DeleteIncidentAsync(int id)
        {
            var incident = await _context.DisasterIncidents.FindAsync(id);
            if (incident != null)
            {
                _context.DisasterIncidents.Remove(incident);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<DisasterIncident>> GetAllIncidentsAsync()
        {
            return await _context.DisasterIncidents
                .OrderByDescending(d => d.ReportedDate)
                .Include(d => d.ReportedBy)
                .ToListAsync();
        }
    }
}