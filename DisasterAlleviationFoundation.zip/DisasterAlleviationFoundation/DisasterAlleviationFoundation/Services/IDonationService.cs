﻿using DisasterAlleviationFoundation.Data;
using DisasterAlleviationFoundation.Models;
using DisasterAlleviationFoundation.Models.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace DisasterAlleviationFoundation.Services
{
    public interface IDonationService
    {
        Task<IEnumerable<Donation>> GetDonationsByUserAsync(string userId);
        Task<IEnumerable<Donation>> GetAllDonationsAsync();
        Task<Donation> GetDonationByIdAsync(int id);
        Task CreateDonationAsync(DonationCreateModel model, string userId);
        Task UpdateDonationStatusAsync(int id, string status);
    }

    public class DonationService : IDonationService
    {
        private readonly AppDbContext _context;

        public DonationService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Donation>> GetDonationsByUserAsync(string userId)
        {
            return await _context.Donations
                .Where(d => d.DonorId == userId)
                .OrderByDescending(d => d.DonatedDate)
                .Include(d => d.DisasterIncident)
                .ToListAsync();
        }

        public async Task<IEnumerable<Donation>> GetAllDonationsAsync()
        {
            return await _context.Donations
                .OrderByDescending(d => d.DonatedDate)
                .Include(d => d.Donor)
                .Include(d => d.DisasterIncident)
                .ToListAsync();
        }

        public async Task<Donation> GetDonationByIdAsync(int id)
        {
            return await _context.Donations
                .Include(d => d.Donor)
                .Include(d => d.DisasterIncident)
                .FirstOrDefaultAsync(d => d.Id == id);
        }

        public async Task CreateDonationAsync(DonationCreateModel model, string userId)
        {
            var donation = new Donation
            {
                ResourceType = model.ResourceType,
                ItemName = model.ItemName,
                Quantity = model.Quantity,
                Description = model.Description,
                DonorId = userId,
                DisasterIncidentId = model.DisasterIncidentId,
                DonatedDate = DateTime.UtcNow,
                Status = "Pending"
            };

            _context.Donations.Add(donation);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateDonationStatusAsync(int id, string status)
        {
            var donation = await _context.Donations.FindAsync(id);
            if (donation != null)
            {
                donation.Status = status;
                await _context.SaveChangesAsync();
            }
        }
    }
}