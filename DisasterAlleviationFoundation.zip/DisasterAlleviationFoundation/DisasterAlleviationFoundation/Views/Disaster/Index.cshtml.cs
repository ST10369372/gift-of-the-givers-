using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterAlleviationFoundation.Views.Disaster
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
