﻿using DisasterAlleviationFoundation.Models;
using Microsoft.AspNetCore.Identity;

namespace DisasterAlleviationFoundation.Data
{
    public static class DbInitializer
    {
        public static async Task Initialize(AppDbContext context,
            UserManager<AppUser> userManager,
            RoleManager<IdentityRole> roleManager)
        {
            // Create roles
            string[] roleNames = { "Admin", "User", "Volunteer" };

            foreach (var roleName in roleNames)
            {
                var roleExist = await roleManager.RoleExistsAsync(roleName);
                if (!roleExist)
                {
                    await roleManager.CreateAsync(new IdentityRole(roleName));
                }
            }

            // Create admin user
            var adminUser = new AppUser
            {
                UserName = "admin@disasterfoundation.org",
                Email = "admin@disasterfoundation.org",
                FirstName = "Admin",
                LastName = "User",
                EmailConfirmed = true
            };

            var adminExists = await userManager.FindByEmailAsync(adminUser.Email);
            if (adminExists == null)
            {
                var createAdmin = await userManager.CreateAsync(adminUser, "Admin123!");
                if (createAdmin.Succeeded)
                {
                    await userManager.AddToRoleAsync(adminUser, "Admin");
                }
            }

            // Seed sample disaster incidents
            if (!context.DisasterIncidents.Any())
            {
                var incidents = new List<DisasterIncident>
                {
                    new DisasterIncident
                    {
                        Title = "Flood in Coastal Region",
                        Description = "Severe flooding affecting multiple towns in the coastal region. Emergency shelters have been set up.",
                        Location = "Coastal Region",
                        ReportedDate = DateTime.UtcNow.AddDays(-5),
                        DisasterType = "Flood",
                        Severity = "High",
                        IsActive = true,
                        ReportedByUserId = adminUser.Id
                    },
                    new DisasterIncident
                    {
                        Title = "Earthquake in Mountain Area",
                        Description = "Moderate earthquake causing structural damage. Rescue operations underway.",
                        Location = "Mountain Region",
                        ReportedDate = DateTime.UtcNow.AddDays(-2),
                        DisasterType = "Earthquake",
                        Severity = "Medium",
                        IsActive = true,
                        ReportedByUserId = adminUser.Id
                    }
                };

                context.DisasterIncidents.AddRange(incidents);
                await context.SaveChangesAsync();
            }
        }
    }
}