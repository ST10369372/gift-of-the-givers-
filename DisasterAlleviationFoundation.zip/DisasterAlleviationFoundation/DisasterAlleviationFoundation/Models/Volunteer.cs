﻿using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models
{
    public class Volunteer
    {
        public int Id { get; set; }

        [Required]
        [StringLength(500)]
        public string Skills { get; set; }

        [Required]
        [StringLength(50)]
        public string Availability { get; set; } // Full-time, Part-time, Emergency

        [Required]
        [StringLength(100)]
        public string Location { get; set; }

        public DateTime RegistrationDate { get; set; } = DateTime.UtcNow;

        public bool IsActive { get; set; } = true;

        // Foreign key
        public string UserId { get; set; }
        public AppUser User { get; set; }

        public virtual ICollection<VolunteerTask> Tasks { get; set; }
    }
}