﻿using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models
{
    public class Donation
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string ResourceType { get; set; } // Food, Clothing, Medical, Money

        [Required]
        [StringLength(100)]
        public string ItemName { get; set; }

        [Required]
        [Range(1, int.MaxValue)]
        public int Quantity { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        [Required]
        public DateTime DonatedDate { get; set; } = DateTime.UtcNow;

        public string Status { get; set; } = "Pending"; // Pending, Approved, Distributed

        // Foreign key
        public string DonorId { get; set; }
        public AppUser Donor { get; set; }

        public int? DisasterIncidentId { get; set; }
        public DisasterIncident DisasterIncident { get; set; }
        public object Amount { get; internal set; }
        public object? DonationDate { get; internal set; }
    }
}