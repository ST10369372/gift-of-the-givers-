﻿using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models.ViewModels
{
    public class DisasterIncidentViewModel
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; }

        [Required]
        [StringLength(500)]
        public string Description { get; set; }

        [Required]
        [StringLength(100)]
        public string Location { get; set; }

        [Required]
        [Display(Name = "Disaster Type")]
        public string DisasterType { get; set; }

        [Required]
        public string Severity { get; set; }

        public bool IsActive { get; set; } = true;
    }

    public class DisasterIncidentCreateModel
    {
        [Required]
        [StringLength(100)]
        public string Title { get; set; }

        [Required]
        [StringLength(500)]
        public string Description { get; set; }

        [Required]
        [StringLength(100)]
        public string Location { get; set; }

        [Required]
        [Display(Name = "Disaster Type")]
        public string DisasterType { get; set; }

        [Required]
        public string Severity { get; set; }
    }
}