﻿using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models.ViewModels
{
    public class VolunteerViewModel
    {
        public int Id { get; set; }

        [Required]
        [StringLength(500)]
        public string Skills { get; set; }

        [Required]
        [StringLength(50)]
        public string Availability { get; set; }

        [Required]
        [StringLength(100)]
        public string Location { get; set; }

        public string UserName { get; set; }
        public string Email { get; set; }
        public string FullName { get; set; }
        public bool IsActive { get; set; }
        public DateTime RegistrationDate { get; set; }
    }

    public class VolunteerRegisterModel
    {
        [Required]
        [StringLength(500)]
        public string Skills { get; set; }

        [Required]
        [StringLength(50)]
        public string Availability { get; set; }

        [Required]
        [StringLength(100)]
        public string Location { get; set; }
    }

    public class VolunteerTaskViewModel
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string TaskName { get; set; }

        [Required]
        [StringLength(500)]
        public string Description { get; set; }

        [Required]
        public DateTime ScheduledDate { get; set; }

        [Required]
        [StringLength(100)]
        public string Location { get; set; }

        public string Status { get; set; }
        public string VolunteerName { get; set; }
        public int? VolunteerId { get; set; }
        public string DisasterTitle { get; set; }
        public int? DisasterIncidentId { get; set; }
    }
}