﻿using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models.ViewModels
{
    public class DonationViewModel
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Resource Type")]
        public string ResourceType { get; set; }

        [Required]
        [Display(Name = "Item Name")]
        [StringLength(100)]
        public string ItemName { get; set; }

        [Required]
        [Range(1, int.MaxValue)]
        public int Quantity { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        [Display(Name = "Disaster Incident")]
        public int? DisasterIncidentId { get; set; }

        public string Status { get; set; }
        public DateTime DonatedDate { get; set; }
        public string DonorName { get; set; }
    }

    public class DonationCreateModel
    {
        [Required]
        [Display(Name = "Resource Type")]
        public string ResourceType { get; set; }

        [Required]
        [Display(Name = "Item Name")]
        [StringLength(100)]
        public string ItemName { get; set; }

        [Required]
        [Range(1, int.MaxValue)]
        public int Quantity { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        [Display(Name = "Allocate to Disaster Incident")]
        public int? DisasterIncidentId { get; set; }
    }
}