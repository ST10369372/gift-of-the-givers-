﻿using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models
{
    public class DisasterIncident
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; }

        [Required]
        [StringLength(500)]
        public string Description { get; set; }

        [Required]
        [StringLength(100)]
        public string Location { get; set; }

        [Required]
        public DateTime ReportedDate { get; set; } = DateTime.UtcNow;

        [Required]
        public string DisasterType { get; set; } // Flood, Earthquake, Fire, etc.

        [Required]
        public string Severity { get; set; } // Low, Medium, High, Critical

        public bool IsActive { get; set; } = true;

        // Foreign key
        public string ReportedByUserId { get; set; }
        public AppUser ReportedBy { get; set; }
        public object? IncidentDate { get; internal set; }
    }
}