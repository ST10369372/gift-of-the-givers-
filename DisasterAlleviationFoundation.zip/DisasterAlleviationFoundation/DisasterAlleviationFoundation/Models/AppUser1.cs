﻿namespace DisasterAlleviationFoundation.Data
{
    public class AppUser
    {
        public string UserName { get; internal set; }
    }
}