﻿using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models
{
    public class VolunteerTask
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string TaskName { get; set; }

        [Required]
        [StringLength(500)]
        public string Description { get; set; }

        [Required]
        public DateTime ScheduledDate { get; set; }

        [Required]
        [StringLength(100)]
        public string Location { get; set; }

        [Required]
        public string Status { get; set; } = "Pending"; // Pending, Assigned, Completed

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        // Foreign keys
        public int? DisasterIncidentId { get; set; }
        public DisasterIncident DisasterIncident { get; set; }

        public int? VolunteerId { get; set; }
        public Volunteer Volunteer { get; set; }
        public object? AssignedDate { get; internal set; }
    }
}